﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegistryBackupRestore
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
			DateTime creation = File.GetCreationTime("C:\\Users\\Madhushanka\\Desktop\\export.reg");
			label3.Text = creation.ToString("dd/MM/yyyy"); ;

			long length = new System.IO.FileInfo("C:\\Users\\Madhushanka\\Desktop\\export.reg").Length;
			label4.Text = length.ToString();
		}

		private void backupBtn_Click(object sender, EventArgs e)
		{
			//Export File Path goes here
			string path = "\"" + "C:\\Users\\Madhushanka\\Desktop\\export.reg" + "\"";
			// Registry Key goes here
			string key = "\"" + @"HKEY_CURRENT_USER\Software" + "\"";
			Process proc = new Process();

			try
			{
				proc.StartInfo.FileName = "regedit.exe";
				proc.StartInfo.UseShellExecute = false;

				proc = Process.Start("regedit.exe", "/e " + path + " " + key);
				proc.WaitForExit();
			}
			catch (Exception)
			{
				proc.Dispose();
			}
			
		}

		private void restoreBtn_Click(object sender, EventArgs e)
		{
			//Restore code goes here
		}
	}
}
